<?php
//function to add new patient data to database
function add_patient($rsa_id, $patient_name, $patient_surname, $patient_address, $medical_aid, $member_number, $contact_number) {
    global $db;
    $query = 'INSERT INTO patients
                 (IDNumber,PatientName,PatientSurname,PatientAddress,MedicalAid,MemberNr,ContactNr)
              VALUES
                 (:id_number,:patientName,:patientSurname,:patientAddress,:medaid,:member_number,:contact_number)';
    $statement = $db->prepare($query);
    $statement->bindValue(':id_number',$rsa_id);
    $statement->bindValue(':patientName',$patient_name);
    $statement->bindValue(':patientSurname',$patient_surname);
    $statement->bindValue(':patientAddress',$patient_address);
    $statement->bindValue(':medaid',$medical_aid);
    $statement->bindValue(':member_number',$member_number);
    $statement->bindValue(':contact_number',$contact_number);
    $statement->execute();
    $statement->closeCursor();
}

//function to validate if patient already exists in database
function validate_patient($rsa_id){
    global $db;
    $validate_id = 'SELECT IDNumber
                      FROM patients
                      WHERE IDNumber = :id';

    $statement_validate = $db->prepare($validate_id);
    $statement_validate->bindValue(':id',$rsa_id);
    $statement_validate->execute();
    $id = $statement_validate-> fetch();
    return $id;

}


//function to get all patients from database
function get_patients() {
    global $db;
    $query = 'SELECT * FROM patients';
    $statement = $db->prepare($query);
    $statement->execute();
    $patients = $statement->fetchAll();
    $statement->closeCursor();
    return $patients;
}

//function to delete patient from database based on id number
function delete_patient($id) {
    global $db;
    $query = 'DELETE FROM patients
              WHERE IDNumber = :id';
    $statement = $db->prepare($query);
    $statement->bindValue(':id',$id);
    $statement->execute();
    $statement->closeCursor(); 
}

function get_patient_details($id) {
    global $db;
    $query = 'SELECT *
                      FROM patients
                      WHERE IDNumber = :id';

    $statement= $db->prepare($query);
    $statement->bindValue(':id',$id);
    $statement->execute();
    $patients = $statement-> fetchAll();
    return $patients;
}

function update_patient($rsa_id, $patient_name, $patient_surname, $patient_address, $medical_aid, $member_number, $contact_number) {
    global $db;
    $query = 'UPDATE patients
              SET   PatientName = :patientName,
                    PatientSurname = :patientSurname,
                    PatientAddress = :patientAddress,
                    MedicalAid = :medaid,
                    MemberNr = :member_number,
                    ContactNr = :contact_number
            WHERE IDNumber = :id_number';

    $statement = $db->prepare($query);
    $statement->bindValue(':id_number',$rsa_id);
    $statement->bindValue(':patientName',$patient_name);
    $statement->bindValue(':patientSurname',$patient_surname);
    $statement->bindValue(':patientAddress',$patient_address);
    $statement->bindValue(':medaid',$medical_aid);
    $statement->bindValue(':member_number',$member_number);
    $statement->bindValue(':contact_number',$contact_number);
    $statement->execute();
    $statement->closeCursor();
}

?>