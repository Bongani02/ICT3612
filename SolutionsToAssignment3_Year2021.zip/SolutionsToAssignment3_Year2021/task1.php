<?php 

/*--------------------------------TASK 1 (a)-----------------------------------------*/
function processStrings_1($stringsArray) {
    
    //loop through each string in the array
        for($i = 0; $i < count($stringsArray); $i++) {
            $stringsArray[$i] = ucfirst($stringsArray[$i]) . '.';             
        }
        return $stringsArray;  
}

function processStrings_2(&$stringsArray) {    

    //loop through each string in the array
        for($i = 0; $i < count($stringsArray); $i++) {
            $stringsArray[$i] = ucfirst($stringsArray[$i]) .'.';              
        }
         
}

/*--------------------------------TASK 1 (b)-----------------------------------------*/
function displayStrings() {
    //declare variables
    $newString;

    //loop through each argument
    $strings = func_get_args();
    foreach($strings as $currentString) {
        $newString = $currentString . substr($currentString,0,1);
        echo '<p>' . $newString . '</p>';
    }
}

/*--------------------------------TASK 1 (c)-----------------------------------------*/
function calculateVAT($amount,$vatRate=15){
    //declare variables
    $totalAmount = 0;

    //calculate totalAmount payable
    $totalAmount = $amount * (1 + $vatRate/100);

    echo '<p> Total Amount: R' . $totalAmount . '</p>';
}
?>

<!-- HTML code to produce output-->

<!DOCTYPE html>
<html>

<head>
    <title>Task 1</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>

<body>    
    <br>
    <br>  
    
    <main>

        <p>
        <h4>TASK 1 (a)</h4>
        <?php   
            //declare array
            $stringArray = array('good luck','best wishes','get well soon');
        ?>
            New Array: <?php print_r(processStrings_1($stringArray));?>
            <br>
            <br>
            Original Array: <?php print_r($stringArray);?>
            <br>
            <br>
			<?php processStrings_2($stringArray); ?>
            Original Array: <?php print_r($stringArray);?>
        </p>
        <hr>
        <p>
        <h4>TASK 1 (b)</h4>
            <?php 
                displayStrings("Gauteng ", "North West ");
                displayStrings("Tshwane ", "Durban ", "Polokwane ", "Pretoria ");
            ?>
        </p>
        <hr>
        <p>
        <h4>TASK 1 (c)</h4>
            <?php 
                calculateVAT(80);
                calculateVAT(80,8);
            ?>
        </p>
        <hr>
        <p>
        <h4>TASK 1 (d)</h4>
        <?php
        /*--------------------------------TASK 1 (d)-----------------------------------------*/
        //declare variables        
        $values = array(6, 98, 54, 13, 25, 70);
        $outputArray = array();
		$availableFunctions = array('shuffle', 'sort', 'rsort', 'array_pop', 'array_reverse');		
		$randomNumber = mt_rand(1,5);
		
		$selectedFunction = $availableFunctions[$randomNumber-1];		
		$returnedValue = $selectedFunction($values);	
		
		echo "Random number: $randomNumber <br>";
		echo "Original array after invoking the randomly selected function: ";		
		print_r($values);   
        echo "<br>Result returned by the random function: ";
		print_r($returnedValue);
		
                
?>
        </p>

    </main>

    <br>
    <br> 

</body>
</html>