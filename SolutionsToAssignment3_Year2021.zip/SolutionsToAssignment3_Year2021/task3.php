<?php
    /*--------------------------------TASK 3 (a)-----------------------------------------*/

    //function to validate input URL
    function validateURL($input) {
        //declare variables
        $url = $input;
        $pattern = '/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i';
                
        if (preg_match($pattern, $url)) {
            echo "The URL is OK.";
        }else {
            echo "Wrong URL.";
        }
    }

    /*--------------------------------TASK 3 (b)-----------------------------------------*/
    //(1)
    function validateLetters($input) {
        //declare variables
        $userInput = $input;
        $pattern = '/[[:lower:]]{4}/';

        if (preg_match($pattern, $userInput)) {
            echo "Input is valid.";
        }else {
            echo "Must be 4 lowercase letters!";
        }
    }
    //(2)
    function validateNumbers($input) {
        //declare variables
        $userInput = $input;
        $pattern = '/\d{6,8}/';

        if (preg_match($pattern, $userInput)) {
            echo "Number is valid.";
        }else {
            echo "Please enter a 6 to 8 digit number!";
        }
    }

        ?>


<!DOCTYPE html>
<html>

<head>
    <title>Task 3</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>

<body>    

<main>
    <!--------------------------------TASK 3 (a)----------------------------------------->
    <h4>TASK 3 (a)</h4>
    <p>
        <?php 
            $input = 'https://unisa.ac.za';
            echo $input . '<br>';
            echo validateURL($input). '<br>'. '<br>';

            $input = 'www.unisa.ac.za';
            echo $input . '<br>';
            echo validateURL($input);
        ?>
    </p>

    <hr>
    <!--------------------------------TASK 3 (b)----------------------------------------->
    <h4>TASK 3 (b)</h4>
    <h5>(1)</h5>
    <p>
        <?php 
            $input = 'ABC';
            echo $input . '<br>';
            echo validateLetters($input). '<br>'. '<br>';

            $input = 'abcd';
            echo $input . '<br>';
            echo validateLetters($input);
        ?>
    </p>

    <h5>(2)</h5>
    <p>
        <?php 
            $input = '77845';
            echo $input . '<br>';
            echo validateNumbers($input). '<br>'. '<br>';

            $input = '6583129';
            echo $input . '<br>';
            echo validateNumbers($input);
        ?>
    </p>



    
</main>    
   

<br>
<br>
<br>
<br>
<br>

</body>
</html>