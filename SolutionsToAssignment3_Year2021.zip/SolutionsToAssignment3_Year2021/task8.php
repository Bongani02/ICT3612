<!DOCTYPE html>
<html>
<head>
    <title>Task 8</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>    
<main>
<!--//////////////////////////////////////////////////////////////////TASK 8//////////////////////////////////////////////////////////////////////-->  

<p>Problem: With the Covid-19 pandemic currently in its third wave in South-Africa, local communities must register to be vaccinated. Our community is struggling to identify
the people that will be willing to take the vaccination, therefore making it difficult for the government and health authorities to plan ahead.</p>

<p>Solution: A web based application will be created where community members can register their details.Local health authorities will also have the ability to schedule the vaccinations.
This will help to identify the number of vaccines needed in our community and can also help to track the number of vaccinations already administered in our community.</p>

<hr>
<h1 id="main_header">COVID-19 Community Vaccination Mananger</h1>
<hr>

<?php 
      require('./model/database.php');
      require('./model/patient_db.php'); 
      require('./model/vaccinations_db.php');

$action = filter_input(INPUT_POST, 'action');

if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'Patients';
    }
}

if($action == 'Patients') {
    $patients = get_patients();
    include './view/register_patient.php';
    include './view/patients_list.php';
    
}else if(isset($_POST['add_patient'])) {
    $id = filter_input(INPUT_POST, 'rsa_id',FILTER_VALIDATE_INT);
    $name = filter_input(INPUT_POST, 'patient_name');
    $surname = filter_input(INPUT_POST, 'patient_surname');
    $address = filter_input(INPUT_POST, 'patient_address');
    $medaid = filter_input(INPUT_POST, 'medical_aid');
    $member = filter_input(INPUT_POST, 'member_number');
    $contact = filter_input(INPUT_POST, 'contact_number'); 
    
    $id_exists = validate_patient($_POST['rsa_id']);
    

    if ($id == FALSE || $name == NULL || $surname == NULL || 
        $address == NULL || $contact == NULL) {
        $error = "Invalid patient data. Please complete all fields.";
        include('./errors/error.php');
    }else if (!empty($id_exists)) {
        echo "<p style='color:red;'>Patient with ID Number: $id already exists in the database!</p>";
        echo '<meta http-equiv="refresh" content="1">';
    } else {
        add_patient($id,$name,$surname,$address,$medaid,$member,$contact);
        echo "<p style='color:green;'>Patient with ID Number: $id successfully registered.</p>";
        echo '<meta http-equiv="refresh" content="1">';
    }
}else if ($action == 'delete_patient') {
        $id = filter_input(INPUT_POST, 'id_to_delete');
        delete_patient($id); 
        echo "<p style='color:green;'>Patient with ID Number: $id successfully deleted from database.</p>";
        echo '<meta http-equiv="refresh" content="1">';

}else if ($action == 'Schedule Vaccination') {
        $patients = get_patients();
        include './view/vaccination_schedule.php';

}else if ($action == 'Schedule') {
        $patient_id = filter_input(INPUT_POST, 'patients');
        $vaccine = filter_input(INPUT_POST, 'vaccine');
        $vaccination_date = filter_input(INPUT_POST, 'vaccination_date');
        $vaccination_place = filter_input(INPUT_POST, 'vaccination_place');

        $schedule_exists = check_schedule($_POST['patients']);

        if ($patient_id == NULL || $vaccine == NULL || $vaccination_date == NULL || $vaccination_place == NULL) {
            $patients = get_patients();
            include './view/vaccination_schedule.php';
            $error = "Invalid vaccination data. Please complete all fields.";
            include('./errors/error.php');
        }else if (!empty($schedule_exists)) {
            $patients = get_patients();
            include './view/vaccination_schedule.php';
            echo "<p style='color:red;'>Patient with ID Number: $patient_id already scheduled for the vaccination!</p>";
        }else if ($vaccination_date < date("Y-m-d")) {
            $patients = get_patients();
            include './view/vaccination_schedule.php';
            $error = "$vaccination_date is already past! Please select a future date.";
            include('./errors/error.php');
        }else {
            schedule_vaccination($patient_id,$vaccine,$vaccination_date,$vaccination_place);
            $patients = get_patients();
            include './view/vaccination_schedule.php';
            echo "<p style='color:green;'>Vaccination for patient with ID Number: $patient_id successfully scheduled for $vaccination_date at $vaccination_place .</p>";
        }
    }else if ($action == 'Show Vaccination Schedule') {
        $vaccinations = get_vaccinations();
        include './view/vaccinations_list.php';
    }else if ($action == 'delete_vaccination') {
        $id = filter_input(INPUT_POST, 'id_to_delete_vaccination');
        delete_vaccination($id); 
        echo "<p style='color:green;'>Vaccination for patient with ID Number: $id successfully deleted from database.</p>";
        $vaccinations = get_vaccinations();
        include './view/vaccinations_list.php';
    }else if ($action == 'update_patient') {
        $id = filter_input(INPUT_POST, 'id_to_update');
        $patients = get_patient_details($id);
        include './view/update_patient.php';
        
    }else if ($action == 'update_patient_details') {
        $id = filter_input(INPUT_POST, 'id',FILTER_VALIDATE_INT);
        $name = filter_input(INPUT_POST, 'name');
        $surname = filter_input(INPUT_POST, 'surname');
        $address = filter_input(INPUT_POST, 'address');
        $medaid = filter_input(INPUT_POST, 'medicalAid');
        $member = filter_input(INPUT_POST, 'member');
        $contact = filter_input(INPUT_POST, 'contact');
        
        if(empty($id) || empty($name) || empty($surname) || empty($address) || empty($medaid) || empty($member) || empty($contact)) {
            $error = "Invalid patient data. Please complete all fields.";
            include('./errors/error.php');
            $patients = get_patient_details($id);
            include './view/update_patient.php';  
        }else {
            update_patient($id,$name,$surname,$address,$medaid,$member,$contact);
            echo "<p style='color:green;'>Patient with ID Number: $id successfully updated.</p>";
            echo '<meta http-equiv="refresh" content="1">'; 
        }
    }else if ($action == 'update_vaccination') {
        $id = filter_input(INPUT_POST, 'id_to_update_vaccination');
        $vaccinations = get_vaccination_details($id);
        include './view/update_vaccination.php';
    }else if ($action == 'update_vaccination_details') {
        $id = filter_input(INPUT_POST, 'id',FILTER_VALIDATE_INT);
        $vaccine = filter_input(INPUT_POST, 'vaccine');
        $vaccinationDate = filter_input(INPUT_POST, 'vaccinationDate');
        $vaccinationPlace = filter_input(INPUT_POST, 'vaccinationPlace');
        
        if(empty($id) || empty($vaccine) || empty($vaccinationDate) || empty($vaccinationPlace)) {
            $error = "Invalid vaccination data. Please complete all fields.";
            include('./errors/error.php');
            $vaccinations = get_vaccination_details($id);
            include './view/update_vaccination.php';  
        }else {
            update_vaccination($id, $vaccine, $vaccinationDate, $vaccinationPlace);
            echo "<p style='color:green;'>Vaccination for Patient with ID Number: $id successfully updated.</p>";
            echo '<meta http-equiv="refresh" content="1">'; 
        }
    }
?>
<br>
<br>
<hr>
</main>

</body>
</html>