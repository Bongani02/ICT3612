<?php

/*--------------------------------TASK 2 (a)-----------------------------------------*/
class Car {

    //declare properties
    private $make;
    private $year;
    private $colour;
    private static $objectCount = 0;

    public function __construct($make, $year, $colour) {
        $this->make = $make;
        $this->year = $year;
        $this->colour = $colour;
        self::$objectCount++;
    }

    public function getMake() {
        return $this->make;
    }

    public function getYear() {
        return $this->year;
    }

    public function getColour() {
        return $this->colour;
    }

    public function setMake($makeValue) {
        $this->make = $makeValue;
    }

    public function setYear($yearValue) {
        $this->year = $yearValue;
    }

    public function setColour($colourValue) {
        $this->colour = $colourValue;
    }

    public static function getObjectCount() {
        return self::$objectCount;
    }

    public function __toString() {
        return 'Make:' . $this->make . '; Year:' . $this->year . '; Colour:' . $this->colour;
    }

    public function oldestCar($carObject) {
		
         if($this->year < $carObject->year) {
            return $this;
        }else {
            return $carObject;
        }      
               
    }
}
/*--------------------------------TASK 2 (b)-----------------------------------------*/
abstract class Bonus {
   protected $salary;
   private $bonusType;
   
   public function __construct($salary, $bonusType){
       $this->salary = $salary;
       $this->bonusType = $bonusType;
   }

   public function getType() {
       return $this->bonusType;
   }

   abstract public function calculate();
}

class BirthdayBonus Extends Bonus {
    private $months;

    public function __construct($salary, $months) {
        $this->months = $months;
        parent::__construct($salary, 'Birthday Bonus');
    }

    public function calculate() {
        $amount = 0;
        if ($this->months == 12) {
            $amount = $this->salary;
        } else {
            $amount = $this->salary * ($this->months/12);
        }

        return $amount;
    } 
}

class LongServiceBonus Extends Bonus {
    private $dateEmployed;    

    public function __construct($salary, $dateEmployed) {
        parent::__construct($salary, 'Long Service Bonus');
        $this->dateEmployed = new DateTime(date('Y-m-d',strToTime($dateEmployed))); 
    }

    public function calculate() { 		
		$currentDate = new DateTime(date('Y-m-d'));		
		$duration = $currentDate->diff($this->dateEmployed);
			
        if(($duration->y > 0) && ($duration->y % 5 == 0)) {			
           return $this->salary * (1 + ($duration->y/100));
        }
	}
    
}

class PerformanceBonus Extends Bonus {
    private $score;

    public function __construct($salary, $score) {
        $this->score = $score;
        parent::__construct($salary, 'Performance Bonus');
    }

    public function calculate() {
        if($this->score >= 3.1) {
            return $this->salary + ($this->salary * $this->score/100);
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Task 2</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>

<body>    
    
<main>
    <div>
            <?php
                $car1 = new Car('Opel', '2006', 'Green');
                $car2 = new Car('Honda', '2013', 'White');
            ?>
        
        <!--------------------------------TASK 2 (a)----------------------------------------->
            <p>
            <h4>TASK 2 (a)</h4>
            <?php
                //call get() methods
                echo 
                'Get Car 1 <br>' .
                $car1->getMake() . '<br>' .
                $car1->getYear() . '<br>' .
                $car1->getColour() . '<br>';
                
                echo 
                '<br> Get Car 2 <br>' .
                $car2->getMake() . '<br>' .
                $car2->getYear() . '<br>' .
                $car2->getColour() . '<br>';

                //call set() methods
                $car2->setMake('Suzuki');
                $car2->setYear('2017');
                $car2->setColour('Red');

                //call get() methods after setting values
                echo
                '<br> Get Car 1 (After it has been set to new value) <br>' .
                $car2->getMake() . '<br>' .
                $car2->getYear() . '<br>' .
                $car2->getColour() . '<br>';
                
                //call method to retreive number of objects
                echo ' <br> Get # of Objects <br>' . Car::getObjectCount() .'<br>';

                //call toString() method
                echo
                '<br> Call toString() method <br>' . 
                $car1->__toString() . '<br>';

                //call oldestCar() method
                echo
                '<br> Oldest Car <br>' . 
                $car1->oldestCar($car2);
            ?> 
            </p>
      
    </div>
    <hr>
    <div>
        <!--------------------------------TASK 2 (b)----------------------------------------->
        <p>
        <h4>TASK 2 (b)</h4>
        <?php 

        $bonus1 = new BirthdayBonus(12000, 6);
        $bonus2 = new LongServiceBonus(15000,'2011-03-09');		
        $bonus3 = new PerformanceBonus(30000,3.4);

        $bonusArray = array($bonus1, $bonus2, $bonus3);
                foreach ($bonusArray as $bonus) {
                    echo '<br> Bonus Type: ' . $bonus->getType() . '<br>';
                    echo 'Bonus Value: R' .$bonus->calculate() . '<br>' . '<br>';
                }              
            ?>
        </p>
    </div>

</main>

<br>
<br>
<br>
<br>
<br>

</body>
</html>



