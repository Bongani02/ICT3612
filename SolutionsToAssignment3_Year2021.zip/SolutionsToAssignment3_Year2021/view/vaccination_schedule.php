<main>
    <h2>Schedule Patient Vaccination:</h2>

<section id ="vaccination_form">
    <form action="task8.php" method="post" id="schedule_vaccination">
        <label>Patient:</label>
        <select name="patients" id="patients">

        <?php foreach ($patients as $patient) : ?>
            <option value="<?php echo $patient['IDNumber']; ?>"><?php echo $patient['IDNumber']; ?></option>
        <?php endforeach; ?>
        </select>
        <br>
        <label>Vaccine:</label>
        <select name="vaccine" id="vaccine">
            <option value="Pfizer">Pfizer</option>
            <option value="Johnson & Johnson">Johnson & Johnson</option>
        </select>
        <br>

        <label>Vaccination Date:</label>
        <input type="date" name="vaccination_date" id="vaccination_date">
        <br>

        <label>Place of Vaccination:</label>
        <input type="text" name="vaccination_place" id="vaccination_place">
        <br>

        <input type="submit" name="action" value="Schedule">
        <input type="submit" name="action" value="Patients"/>
        <input type="submit" name="action" value="Show Vaccination Schedule"/>
        </form>
           

        <br>
        <br>


</section>


</main>


