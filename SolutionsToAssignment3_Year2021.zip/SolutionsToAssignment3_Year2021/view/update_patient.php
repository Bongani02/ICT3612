<main>
    <h2>Update Patient Registration:</h2>

    

    <form action="task8.php" method="post" id="register_patient">
        <input type="hidden" name="action" value="update_patient_details"/>

        <?php foreach ($patients as $patient) : ?>
        
        <label>Patient RSA ID number:</label>
        <input type="text" name="id" id="id" value="<?php echo $patient['IDNumber'];?>"/>
        <br>

        <label>Patient Name:</label>
        <input type="text" name="name" id="name" value="<?php echo $patient['PatientName'];?>"/>
        <br>

        <label>Patient Surname:</label>
        <input type="text" name="surname" id="surname" value="<?php echo $patient['PatientSurname'];?>"/>
        <br>

        <label>Patient Address:</label>
        <input type="text" name="address" id="address" value="<?php echo $patient['PatientAddress'];?>"/>
        <br>

        <label>Medical Aid:</label>
        <input type="text" name="medicalAid" id="medicalAid" value="<?php echo $patient['MedicalAid'];?>"/>
        <br>

        <label>Membership number:</label>
        <input type="text" name="member" id="member" value="<?php echo $patient['MemberNr'];?>"/>
        <br>

        <label>Contact number:</label>
        <input type="text" name="contact" id="contact" value="<?php echo $patient['ContactNr'];?>"/>
        <br>
        <br>

  
        <input type="submit" name ="update_patient_details" value="Update">
        <input type="submit" name="action" value="Patients"/>
        <br>
        <br>

        <?php endforeach; ?>

    </form>

    
</main>


