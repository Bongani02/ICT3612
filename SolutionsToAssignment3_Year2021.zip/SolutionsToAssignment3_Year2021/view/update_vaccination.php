<main>
    <h2>Update Vaccination:</h2>

    

    <form action="task8.php" method="post" id="register_patient">
        <input type="hidden" name="action" value="update_vaccination_details"/>

        <?php foreach ($vaccinations as $vaccination) : ?>
        
        <label>Patient:</label>
        <input type="text" name="id" id="id" value="<?php echo $vaccination['IDNumber'];?>"/>
        <br>

        <label>Vaccine:</label>
        <input type="text" name="vaccine" id="vaccine" value="<?php echo $vaccination['Vaccine'];?>"/>
        <br>

        <label>Vaccination Date:</label>
        <input type="date" name="vaccinationDate" id="vaccinationDate" value="<?php echo $vaccination['VaccinationDate'];?>"/>
        <br>

        <label>Place of Vaccination:</label>
        <input type="text" name="vaccinationPlace" id="vaccinationPlace" value="<?php echo $vaccination['VaccinationPlace'];?>"/>
        <br>

  
        <input type="submit" name ="update_vaccination_details" value="Update">
        <input type="submit" name="action" value="Show Vaccination Schedule"/>
        <br>
        <br>

        <?php endforeach; ?>

    </form>

    
</main>


