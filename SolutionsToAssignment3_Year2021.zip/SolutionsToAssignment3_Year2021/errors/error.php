<main>
    <p style='color:red;'><?php echo $error; ?></p>
</main>