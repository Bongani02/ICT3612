<main>
    <h1>Database Error</h1>
    <p class="errors">There was an error connecting to the database.</p>
    <p class="errors">Error message: <?php echo $error_message; ?></p>
</main>