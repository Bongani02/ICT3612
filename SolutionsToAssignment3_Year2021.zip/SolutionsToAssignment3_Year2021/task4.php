<!DOCTYPE html>
<html>

<head>
    <title>Task 4</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>

<body>
   

<main>
    <h4>TASK 4:</h4>

    <p>
        Customers:<br>
        Customer ID -> PK <br>
    <hr>
        Orders: <br>
        Order ID -> PK <br>
        Customer ID -> FK <br>
        Employee ID -> FK <br>
        Shipper ID -> FK <br>
    <hr>
        Order Details: <br>
        Order ID -> PK <br>
        Product ID -> FK
    <hr>
        Products: <br>
        Product ID -> PK <br>
        Supplier ID -> FK <br>
        Category ID -> FK <br>
    <hr>
        Categories: <br>
        Category ID -> PK <br>
    <hr>
        Suppliers: <br>
        Supplier ID -> PK <br>
    <hr>
        Shippers: <br>
        Shipper ID -> PK <br>
    <hr>
        Employees: <br>
        Employee ID -> PK <br>

    </p>
 
</main>


<br>
<br>
<br>
<br>
<br>


</body>
</html>