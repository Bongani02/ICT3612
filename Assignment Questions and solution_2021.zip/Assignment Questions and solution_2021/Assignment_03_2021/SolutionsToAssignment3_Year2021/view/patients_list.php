<main>
        <!-- display a list of patients -->
        <h2>Registered Patients:</h2>
        <table id="patients_table">
        <tr>
            <th>IDNumber</th>
            <th>PatientName</th>
            <th>PatientSurname</th>
            <th>PatientAddress</th>
            <th>MedicalAid</th>
            <th>MemberNr</th>
            <th>ContactNr</th>
        </tr>
        <?php foreach ($patients as $patient) : ?>
            <tr>
                <td><?php echo $patient['IDNumber']; ?></td>
                <td><?php echo $patient['PatientName']; ?></td>
                <td><?php echo $patient['PatientSurname']; ?></td>
                <td><?php echo $patient['PatientAddress']; ?></td>
                <td><?php echo $patient['MedicalAid']; ?></td>
                <td><?php echo $patient['MemberNr']; ?></td>
                <td><?php echo $patient['ContactNr']; ?></td>

                <td>  
                    <form action="task8.php" method="post">
                        <input type="hidden" name="action"
                            value="delete_patient">
                        <input type="hidden" name="id_to_delete"
                            value="<?php echo $patient['IDNumber'];?>">
                        <input type="submit" value="Delete">
                    </form> 
                </td>

                <td>
                    <form action="task8.php" method="post">
                        <input type="hidden" name="action"
                            value="update_patient">
                        <input type="hidden" name="id_to_update"
                            value="<?php echo $patient['IDNumber'];?>">
                        <input type="submit" value="Update">
                    </form>
                </td>

               
            
            
            
                
            </tr>
            <?php endforeach; ?>
        </table>
        <br>
        <br>
        
            <form action="task8.php" method="post">
            <input type="submit" name="action" value="Schedule Vaccination"/>

            <form action="task8.php" method="post">
            <input type="submit" name="action" value="Show Vaccination Schedule"/>
</main>