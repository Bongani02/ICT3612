<main>
    <h2>New Patient Registration:</h2>

    <form action="task8.php" method="post" id="register_patient">
        <input type="hidden" name="action" value="add_patient"/>
        
        <label>Patient RSA ID number:</label>
        <input type="text" name="rsa_id" id="rsa_id">
        <br>

        <label>Patient Name:</label>
        <input type="text" name="patient_name" id="patient_name"/>
        <br>

        <label>Patient Surname:</label>
        <input type="text" name="patient_surname" id="patient_surname"/>
        <br>

        <label>Patient Address:</label>
        <input type="text" name="patient_address" id="patient_address"/>
        <br>

        <label>Medical Aid:</label>
        <input type="text" name="medical_aid" id="medical_aid"/>
        <br>

        <label>Membership number:</label>
        <input type="text" name="member_number" id="member_number"/>
        <br>

        <label>Contact number:</label>
        <input type="text" name="contact_number" id="contact_number"/>
        <br>
        <br>


        <input type="submit" name ="add_patient" value="Register">
        <br>
        <br>

    </form>
</main>


