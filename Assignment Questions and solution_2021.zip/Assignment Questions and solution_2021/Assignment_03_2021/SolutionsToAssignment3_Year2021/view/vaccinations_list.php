<main>
        <!-- display a list of vaccinations -->
        <h2>Scheduled Vaccinations:</h2>
        <table id="vaccinations_table">
        <tr>
            <th>IDNumber</th>
            <th>Vaccine</th>
            <th>VaccinationDate</th>
            <th>VaccinationPlace</th>
        </tr>
        <?php foreach ($vaccinations as $vaccination) : ?>
            <tr>
                <td><?php echo $vaccination['IDNumber']; ?></td>
                <td><?php echo $vaccination['Vaccine']; ?></td>
                <td><?php echo $vaccination['VaccinationDate']; ?></td>
                <td><?php echo $vaccination['VaccinationPlace']; ?></td>
                <td><form action="task8.php" method="post">
                    <input type="hidden" name="action"
                           value="delete_vaccination">
                    <input type="hidden" name="id_to_delete_vaccination"
                           value="<?php echo $vaccination['IDNumber'];?>">
                    <input type="submit" value="Delete">
                </form></td>
                <td><form action="task8.php" method="post">
                    <input type="hidden" name="action"
                           value="update_vaccination">
                    <input type="hidden" name="id_to_update_vaccination"
                           value="<?php echo $vaccination['IDNumber'];?>">
                    <input type="submit" value="Update">
                </form></td>

            </tr>
            <?php endforeach; ?>
        </table>
        <br>
        <br>
        
            <form action="task8.php" method="post">
                <input type="submit" name="action" value="Schedule Vaccination"/>
                <input type="submit" name="action" value="Patients"/>
                <input type="submit" name="action" value="Show Vaccination Schedule"/>
            </form>
</main>