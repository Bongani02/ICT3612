<?php
//function to add new patient data to database
function schedule_vaccination($id_number, $vaccine, $vaccinationDate, $vaccinationPlace) {
    global $db;
    $query = 'INSERT INTO vaccinations
                 (IDNumber,Vaccine,VaccinationDate,VaccinationPlace)
              VALUES
                 (:id_number,:vaccine,:vaccination_date,:vaccination_place)';
    $statement = $db->prepare($query);
    $statement->bindValue(':id_number',$id_number);
    $statement->bindValue(':vaccine',$vaccine);
    $statement->bindValue(':vaccination_date',$vaccinationDate);
    $statement->bindValue(':vaccination_place',$vaccinationPlace);
    $statement->execute();
    $statement->closeCursor();
}

//function to check if id is already scheduled for a vaccination
function check_schedule($rsa_id){
    global $db;
    $validate_id = 'SELECT IDNumber
                      FROM vaccinations
                      WHERE IDNumber = :id';

    $statement_validate = $db->prepare($validate_id);
    $statement_validate->bindValue(':id',$rsa_id);
    $statement_validate->execute();
    $id = $statement_validate-> fetch();
    return $id;

}

//function to get all vaccinations from database
function get_vaccinations() {
    global $db;
    $query = 'SELECT * FROM vaccinations';
    $statement = $db->prepare($query);
    $statement->execute();
    $vaccinations = $statement->fetchAll();
    $statement->closeCursor();
    return $vaccinations;
}

//function to delete vaccination from database based on id number
function delete_vaccination($id) {
    global $db;
    $query = 'DELETE FROM vaccinations
              WHERE IDNumber = :id';
    $statement = $db->prepare($query);
    $statement->bindValue(':id',$id);
    $statement->execute();
    $statement->closeCursor(); 
}

function get_vaccination_details($id) {
    global $db;
    $query = 'SELECT *
                      FROM vaccinations
                      WHERE IDNumber = :id';

    $statement= $db->prepare($query);
    $statement->bindValue(':id',$id);
    $statement->execute();
    $vaccinations = $statement-> fetchAll();
    return $vaccinations;
}

function update_vaccination($id_number, $vaccine, $vaccinationDate, $vaccinationPlace) {
    global $db;
    $query = 'UPDATE vaccinations
              SET   Vaccine = :vaccine,
                    VaccinationDate = :vaccinationDate,
                    VaccinationPlace = :vaccinationPlace
            WHERE IDNumber = :id_number';

    $statement = $db->prepare($query);
    $statement->bindValue(':id_number',$id_number);
    $statement->bindValue(':vaccine',$vaccine);
    $statement->bindValue(':vaccinationDate',$vaccinationDate);
    $statement->bindValue(':vaccinationPlace',$vaccinationPlace);
    $statement->execute();
    $statement->closeCursor();
}
?>