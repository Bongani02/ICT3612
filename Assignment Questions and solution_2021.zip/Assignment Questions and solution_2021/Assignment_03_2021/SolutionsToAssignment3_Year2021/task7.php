<!DOCTYPE html>
<html>
<head>
    <title>Task 7</title>
    <link rel="stylesheet" type="text/css" href="main.css">
    <style>
        #error {
            color: red;
        }
        #filelist {
         list-style-type: circle;
        }
    </style>
</head>
<body>    
<main>
<!--//////////////////////////////////////////////////////////////////TASK 7(a)//////////////////////////////////////////////////////////////////////-->  

<h2>Create new file with some text</h2>
<label>Filename (With file extension):</label>
<form action="" method="post">
<input type="text" name="filename" id="filename">
<br>
<label>Enter file contents:</label><br>
<textarea name="userText" id="userText" cols="30" rows="10"></textarea><br>
<button type="submit" name="create">Create file with specified contents</button>
<button type="submit" name="view">View file contents</button>
<button type="submit" name="download">Download File</button>
<button type="submit" name="viewFiles">View Files in Directory</button><br><br>
</form>

<?php 

//////////////////////////// TASK 7 (a)///////////////////////////////

if(isset($_POST['create'])) {

//declare variables
$filename = filter_input(INPUT_POST,'filename');
$fileData = filter_input(INPUT_POST,'userText');

    //check if file already exists
    if(file_exists($filename)) {
        echo '<p id="error">File already exists!</p>';
    }else {
        //create new file and write contents to file
        $file = fopen($filename,"w");
        fwrite($file,$fileData);
        echo '<p>File successfully created</p>';
    }
}

//////////////////////////// TASK 7 (b)///////////////////////////////

if(isset($_POST['view'])) {

    $filename = filter_input(INPUT_POST,'filename');
    if($filename == null) {
        echo "Please enter a filename!";
    }else if (file_exists($filename)) {
        $fileText = file_get_contents($filename);
        echo '<div>' . $fileText . '</div>';
    }else echo "Specified file does not exist";
}

//////////////////////////// TASK 7 (c)///////////////////////////////
if(isset($_POST['download'])) {

    $filename = filter_input(INPUT_POST,'filename');

    if (file_exists($filename)) {
        readfile($filename);
        exit;
}
}

if(isset($_POST['viewFiles'])) {

    $path = getcwd();
    $items = scandir($path);
    echo '<p>Files in directory:</p>';
    echo '<ul id="filelist">';
    foreach ($items as $item) {
        echo '<li>' . $item . '</li>' . '<br>';
    }
    echo '</ul>';
    }
?>

<br>
<br>
<br>
<br>

</main>




</body>
</html>