<!DOCTYPE html>
<html>
<head>
    <title>Task 6</title>
    <link rel="stylesheet" type="text/css" href="main.css">
    <style>
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    </style>
</head>
<body>    
<main>
<!--//////////////////////////////////////////////////////////////////TASK 6//////////////////////////////////////////////////////////////////////-->  
<table>
<tr>
    <th>Website URL</th>
    <th>Certification Authority</th>
    <th>Certificate Expiry Date</th>
</tr>
<tr>
    <td>https://vaccine.enroll.health.gov.za/#/</td>
    <td>R3</td>
    <td>2021/09/26</td>
</tr>
<tr>
    <td>https://www.fnb.co.za/</td>
    <td>Entrust Certification Authority - L1M</td>
    <td>2022/06/12</td>
</tr>
<tr>
    <td>https://www.absa.co.za/personal/</td>
    <td>DigiCert SHA2 Secure Server CA</td>
    <td>2022/06/24</td>
</tr>
<tr>
    <td>https://www.capitecbank.co.za/</td>
    <td>Entrust Certification Authority - L1M</td>
    <td>2022/07/30</td>
</tr>
<tr>
    <td>https://www.sanlam.co.za/Pages/default.aspx</td>
    <td>Entrust Certification Authority - L1K</td>
    <td>2021/11/04</td>
</tr>
</table>
</main>

<br>
<br>
<br>
<br>
<br>

</body>
</html>